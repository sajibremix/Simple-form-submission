<?php echo e(header('Content-Type: text/html; charset=utf-8')); ?>


<?php $__env->startSection('content'); ?>



<div style="margin-bottom: 20px; width: 300px; float: right;">
  <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-filter"></i></span><input class="form-control" type="text" name="daterange" value="" /></div>
</div>


<div class="table-responsive" id="submission_data" style="width: 100%">
  <!-- Navbar Area Starts -->
  <?php echo $__env->make('sections/data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Navbar Area End -->
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/submission_data.blade.php ENDPATH**/ ?>
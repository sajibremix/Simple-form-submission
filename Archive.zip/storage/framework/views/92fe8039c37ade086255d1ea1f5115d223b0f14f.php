<!DOCTYPE html>
<html>
<head>
	<title><?php echo e(env('APP_NAME')); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<!------ Include the above in your HEAD tag ---------->
</head>
<body>
    <!-- Navbar Area Starts -->
    <?php echo $__env->make('sections/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar Area End -->

    
	<div class="container">

      <div class="jumbotron">
        <h1>Simple form submission</h1> 
        <p>Demo project done by <b>Jakir Hossen</b></p> 
      </div>

      <!-- Navbar Area Starts -->
      <?php echo $__env->make('sections/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Navbar Area End --><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/header.blade.php ENDPATH**/ ?>
<?php echo e(header('Content-Type: text/html; charset=utf-8')); ?>


<?php $__env->startSection('content'); ?>

<h1>#Simple form submission application</h1>
<p>Framework: <b>Laravel</b></p>
<p>Library: <b>bootstrap, jquery, datetimepicker</b></p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/home.blade.php ENDPATH**/ ?>
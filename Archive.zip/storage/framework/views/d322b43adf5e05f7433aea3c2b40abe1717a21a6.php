<?php echo e(header('Content-Type: text/html; charset=utf-8')); ?>


<?php $__env->startSection('content'); ?>
       <form class="well form-horizontal simple_form" action="<?php echo e(route('forms.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
          <fieldset>
            <h2 class="text-center">Your form</h2> 
            <hr>
             <div class="form-group">
                <label class="col-md-4 control-label">Amount</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span><input name="amount" placeholder="Amount" class="form-control" required="true" value="" type="number"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Buyer</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input name="buyer" placeholder="Buyer" class="form-control" required="true" value="" type="text"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Receipt id</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span><input name="receipt_id" placeholder="Receipt id" class="form-control" required="true" value="" type="text"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Items</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span><input name="items" placeholder="Items" class="form-control" required="true" value="" type="text"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">buyer_email</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span><input name="buyer_email" placeholder="Buyer email" class="form-control" required="true" value="" type="text"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Note</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span><textarea name="note" placeholder="Note" class="form-control" required="true" rows="5"></textarea></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">City</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span><input name="city" placeholder="City" class="form-control" required="true" value="" type="text"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Phone</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span><input name="phone" placeholder="Phone" class="form-control" required="true" value="" type="number"></div>
                   <p class="error"></p>
                </div>
             </div>
             <div class="form-group">
                <label class="col-md-4 control-label">Entry by</label>
                <div class="col-md-8 inputGroupContainer">
                   <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-star"></i></span><input name="entry_by" placeholder="Entry by" class="form-control" required="true" value="" type="number"></div>
                   <p class="error"></p>
                </div>
             </div>

             <div class="form-group">
                <label class="col-md-4 control-label"></label>
                <div class="col-md-8 inputGroupContainer">
                   <button type="submit" class="btn btn-primary">Submit</button>
                </div>
             </div>
          </fieldset>
       </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/simple_form_submission/resources/views/sections/form.blade.php ENDPATH**/ ?>
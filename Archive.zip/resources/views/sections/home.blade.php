@extends('layout')
{{header('Content-Type: text/html; charset=utf-8')}}

@section('content')

<h1>#Simple form submission application</h1>
<p>Framework: <b>Laravel</b></p>
<p>Library: <b>bootstrap, jquery, datetimepicker, jquery validator</b></p>
@endsection


